package com.inesc.conspec.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.List;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.configuration2.ex.ConfigurationRuntimeException;

public class GenerateSerial {
	private static int cnt = 0;
	private static String pathTLAmod = "C:/Users/user/Downloads/tla/tla/tla2sany/StandardModules/";
	private static String pathFile = "/Users/subhajitsidhanta/Downloads/Spin/";
	private static List<String[]> retList = new  ArrayList<String[]>();
	static List<String[]> permute(java.util.List<String> arr, int k){
		//List<String[]> retList = new  ArrayList<String[]>();
		String[] retArr = new String[arr.size()];
        for(int i = k; i < arr.size(); i++){
            java.util.Collections.swap(arr, i, k);
            cnt=cnt+k;
            //cnt++;
            permute(arr, k+1);
            //cnt++;
            java.util.Collections.swap(arr, k, i);
            
        }
        boolean valperm = true;
        for(int l = 0; l < arr.size(); l++){
        	if(arr.get(l) == null) 
        	{
        		valperm = false;
        		break;
        	}
		}
        //if(valperm)
        //System.out.println("arr valperm:"+java.util.Arrays.toString(arr.toArray()));
        if (ValidSer(arr) && valperm && k == arr.size() -1){
        	//System.out.println("222 valperm:"+java.util.Arrays.toString(arr.toArray()));
        	for(int l = 0; l < arr.size(); l++){
                	if(arr.get(l) != null) 
                		retArr[l] = arr.get(l).replace(">>", ">").replace("<<", "<");
        		}
        		retList.add(retArr);
        		//System.out.println("11cnt:"+cnt+" arr:"+java.util.Arrays.toString(retArr));
        }
        //System.out.println("11cnt:"+retList.size()+" arr:"+java.util.Arrays.toString(retArr));
        return retList;
    }

	private static boolean ValidSer(List<String> arr) {
		// TODO Auto-generated method stub
		boolean checked = true;
		String objCheck = null;
		int valCheck = -999999, indexCheck = 0; 
		for(int i=0; i<arr.size();i++)
		{
			if(!checked && i >= indexCheck + 1 && arr.get(i).contains(",") &&  arr.get(i).split(",")[1]!=null && !"".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && "w".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && objCheck.equalsIgnoreCase((String)arr.get(i).split(",")[2]) )
			{
				//indexCheck = 0;
				valCheck = Integer.parseInt(arr.get(i).split(",")[3]);
				checked = true;
			}
			if(!checked && arr.get(i).contains(",") &&  arr.get(i).split(",")[1]!=null && !"".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && "r".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && objCheck.equalsIgnoreCase((String)arr.get(i).split(",")[2]) && valCheck == Integer.parseInt(arr.get(i).split(",")[3]))
			{
				checked = true;
				valCheck = -999999;
			}
			if(checked && arr.get(i).contains(",") &&  arr.get(i).split(",")[1]!=null && !"".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && "w".equalsIgnoreCase((String)arr.get(i).split(",")[1]))
			{
				objCheck = arr.get(i).split(",")[2];
				indexCheck = i;
				valCheck = Integer.parseInt(arr.get(i).split(",")[3]);
				checked = false;
			}
			//System.out.println("indexCheck:"+indexCheck+" valCheck:"+valCheck+" checked:"+checked);
			if(!checked && indexCheck > 0 && (indexCheck+1)%2 == 0)
				break;
		}
		return checked;
	}

	public static void main(String[] args) {
		// <timestamp, operation type: w/r, object, value>
			String str = "";//"<1,w,x,1>,<2,w,x,2>,<3,r,x,2>,<4,r,x,1>";
			String file1 = pathFile+"training_data.arff";
			try (BufferedReader br = new BufferedReader(new FileReader(file1))) {
			    String line;
			    int i =0;
			    while ((line = br.readLine()) != null && i>=(Integer.parseInt(args[1]) * Integer.parseInt(args[2])-1) && i<=(Integer.parseInt(args[1]) * Integer.parseInt(args[2]))) {
			    	if(i==0)
			    		str = str + "<<" + i + "," + line.split(",")[0].substring(0, 1) + "," + line.split(",")[4] + "," + line.split(",")[5] +">>";
			    	else 
			    		str = str + ",<<" + i + "," + line.split(",")[0].substring(0, 1) + "," + line.split(",")[4] + "," + line.split(",")[5] +">>";
			    	i++;
			       // process the line.
			    }
			   /* FileOutputStream out = new FileOutputStream(pathFile+"training_data.arff");
			    out.write(str.getBytes());
			    out.close();*/
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			//str = args[0].replace("<", "<<");
			//str = str.replace(">", ">>");
			String[] sarr = str.split(">>,<<");
			//String[] sarr = str.replaceAll("\"", "").replaceAll("<", "<<").replaceAll(">", ">>").split(">>,<<");
			 String stStr = System.getProperty("line.separator")+"int size = "+sarr.length+";" + System.getProperty("line.separator");
			 //System.out.println("***str:"+str+" sarr size:"+sarr.length+" sarr 1:"+sarr[1]);
			 //+ "st[0].optype = w;"+System.getProperty("line.separator")+"st[0].var = x;"+System.getProperty("line.separator")+"st[0].val = 1;"+System.getProperty("line.separator")+"st[1].optype = w;"+System.getProperty("line.separator")+"st[1].var = x;"+System.getProperty("line.separator")+"st[1].val = 2;"+System.getProperty("line.separator")+"st[2].optype = r;"+System.getProperty("line.separator")+"st[2].var = x;"+System.getProperty("line.separator")+"st[2].val = 2;"+System.getProperty("line.separator")+"st[3].optype = r;"+System.getProperty("line.separator")+"st[3].var = x;"+System.getProperty("line.separator")+"st[3].val = 1;"+System.getProperty("line.separator");
				
			for(int i=0; i<sarr.length && sarr[i].contains(",");i++)
			{
				sarr[i] = sarr[i].replace("<", "");
				sarr[i] = sarr[i].replace(">", "");
				//System.out.println("st[0].optype = w;sarr[i]:"+sarr[i].split(",")[2]);
				stStr = stStr+"st["+i+"].optype = "+sarr[i].split(",")[1]+";"+ System.getProperty("line.separator") +"st["+i+"].var = "+sarr[i].split(",")[2]+";"+ System.getProperty("line.separator") +"st["+i+"].val = "+sarr[i].split(",")[3]+";"+ System.getProperty("line.separator");
			}
			List<String[]> retList = permute(Arrays.asList(sarr),0);
			//System.out.println("***1sarr 2:"+sarr.length +"3 retList.size():"+retList.size());
			//System.out.println("retarr:"+retList.size());
			String serStr = null;
			for(int l = 0; l < retList.size(); l++){
				serStr = Arrays.toString((String[])retList.get(l));
				if(serStr.contains("["))
					serStr = serStr.replace("[", "");
				if(serStr.contains("]"))
					serStr = serStr.replace("]", "");
				
				int count = 0;
				//System.out.println("***serStr::"+serStr);
				while(count < sarr.length && serStr.contains(",")){
						stStr = stStr + "ser["+l+"].st["+count +"].optype = "+serStr.split(", ")[count].split(",")[1]+";"+ System.getProperty("line.separator") + "ser["+l+"].st["+count +"].var = "+serStr.split(", ")[count].split(",")[2]+";"+ System.getProperty("line.separator")+ "ser["+l+"].st["+count +"].val = "+serStr.split(", ")[count].split(",")[3]+";"+ System.getProperty("line.separator");
						count++;
				}
				
			}
			//System.out.println("****stSserStrtr:"+stStr);
			String line = null;
			BufferedReader in = null;
		    
		    List<String> list = new ArrayList<String>();
		    boolean flagDel = false;
			try{
				in = new BufferedReader(new FileReader(pathFile+"conspec"+args[0]+"Viol.pml"));
	            	while((str = in.readLine()) != null){
	            		if(str.contains("inword"))
	            			flagDel = false;
	            		if(!flagDel)
	            			list.add(str);

	            		if(str.contains("init {"))
	            			flagDel = true;
				    }
	            	in.close();
	            	File file = new File(pathFile+"conspec"+args[0]+"Viol.pml");
	            	file.delete();
			} /*catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}*/ catch (IOException e) {
				in = null;
				line = null;
			// TODO Auto-generated catch block
			e.printStackTrace();
			}  finally
			{
				// TODO Auto-generated catch block
				 	in = null;
				    line = null;
			}
			
			Formatter out = null;
			try{
				    	out = new Formatter(new FileWriter(pathFile+"conspec"+args[0]+"Viol.pml", true));
				    String[] stringArr = list.toArray(new String[0]);
				    //System.out.println("***stringArr.length::"+stringArr.length);
				    for (int i = 0; i < stringArr.length; i++) {
			            line = stringArr[i];
			            if (line.contains("init {")) {
			            	line = line + stStr;
			            }
			            out.format("\t %s \n", line);;
			            out.flush();
					}
		           
		            
		            out.close(); 
				} /*catch (ConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/ catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
