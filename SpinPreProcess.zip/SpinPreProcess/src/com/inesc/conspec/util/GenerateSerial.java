package com.inesc.conspec.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;
import java.util.List;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.configuration2.ex.ConfigurationRuntimeException;

public class GenerateSerial {
	private static int cnt = 0;
	private static String pathTLAmod = "C:/Users/user/Downloads/tla/tla/tla2sany/StandardModules/";
	private static String pathFile = "/Users/subhajitsidhanta/Downloads/Spin/";
	private static List<String[]> retList = new  ArrayList<String[]>();
	static List<String[]> permute(java.util.List<String> arr, int k){
		//List<String[]> retList = new  ArrayList<String[]>();
		String[] retArr = new String[arr.size()];
        for(int i = k; i < arr.size(); i++){
            java.util.Collections.swap(arr, i, k);
            cnt=cnt+k;
            //cnt++;
            permute(arr, k+1);
            //cnt++;
            java.util.Collections.swap(arr, k, i);
            
        }
        boolean valperm = true;
        for(int l = 0; l < arr.size(); l++){
        	if(arr.get(l) == null) 
        	{
        		valperm = false;
        		break;
        	}
		}
        //if(valperm)
        //System.out.println("arr valperm:"+java.util.Arrays.toString(arr.toArray()));
        if (ValidSer(arr) && valperm && k == arr.size() -1){
        	//System.out.println("222 valperm:"+java.util.Arrays.toString(arr.toArray()));
        	for(int l = 0; l < arr.size(); l++){
                	if(arr.get(l) != null) 
                		retArr[l] = arr.get(l).replace(">>", ">").replace("<<", "<");
        		}
        		retList.add(retArr);
        		//System.out.println("11cnt:"+cnt+" arr:"+java.util.Arrays.toString(retArr));
        }
        //System.out.println("11cnt:"+retList.size()+" arr:"+java.util.Arrays.toString(retArr));
        return retList;
    }

	private static boolean ValidSer(List<String> arr) {
		// TODO Auto-generated method stub
		boolean checked = true;
		String objCheck = null;
		double valCheck = -999999;
		int indexCheck = 0; 
		for(int i=0; i<arr.size();i++)
		{
			if(!checked && i >= indexCheck + 1 && arr.get(i).contains(",") &&  arr.get(i).split(",")[1]!=null && !"".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && "w".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && objCheck.equalsIgnoreCase((String)arr.get(i).split(",")[2]) )
			{
				//indexCheck = 0;
				valCheck = Double.parseDouble(arr.get(i).split(",")[3]);//.substring(0, arr.get(i).split(",")[3].indexOf ( "." )));
				checked = true;
			}
			if(!checked && arr.get(i).contains(",") &&  arr.get(i).split(",")[1]!=null && !"".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && "r".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && objCheck.equalsIgnoreCase((String)arr.get(i).split(",")[2]) && valCheck == Integer.parseInt(arr.get(i).split(",")[3]))
			{
				checked = true;
				valCheck = -999999;
			}
			if(checked && arr.get(i).contains(",") &&  arr.get(i).split(",")[1]!=null && !"".equalsIgnoreCase((String)arr.get(i).split(",")[1]) && "w".equalsIgnoreCase((String)arr.get(i).split(",")[1]))
			{
				objCheck = arr.get(i).split(",")[2];//.substring(0, arr.get(i).split(",")[2].indexOf ( "." ));
				indexCheck = i;
				valCheck = Double.parseDouble(arr.get(i).split(",")[3]);//.substring(0, arr.get(i).split(",")[3].indexOf ( "." )));
				checked = false;
			}
			//System.out.println("indexCheck:"+indexCheck+" valCheck:"+valCheck+" checked:"+checked);
			if(!checked && indexCheck > 0 && (indexCheck+1)%2 == 0)
				break;
		}
		return checked;
	}

	public static void main(String[] args) {
		// <timestamp, operation type: w/r, object, value>
			String str = "";//"<1,w,x,1>,<2,w,x,2>,<3,r,x,2>,<4,r,x,1>";
			String file1 = pathFile+"training_data.arff";
			BufferedReader in = null;
			String line = null;
			Formatter out = null;
			boolean flagDel = false;
			String strDel ="";
			//try (
			try{
				
					 BufferedReader br = new BufferedReader(new FileReader(pathFile+"conspec"+args[0]+"Viol.pml")); //{
					
					 while ((line = br.readLine()) != null) {
						 if (line.contains("inword")) {
				            	flagDel = false;
				         }
						 if(flagDel==true)
							 strDel = strDel + "";
				         else
				        	 strDel = strDel + line + System.getProperty("line.separator");
			             if (line.contains("init")) {
			            	flagDel = true;
			             }
			             //line = line + stStr;
			             
			         }
					//System.out.println("***before for loop setting"+strDel);
					File filedel = new File(pathFile+"conspec"+args[0]+"Viol.pml");
		            filedel.delete();
		            
					out = new Formatter(new BufferedWriter(new FileWriter(pathFile+"conspec"+args[0]+"Viol.pml", false)));   
				    out.format("\t %s \n", strDel);;
				    out.flush();
			        out.close();
			        out = null;
			        
			    int i = 0, start = 0, end = 0;
			    start = (Integer.parseInt(args[1]))*Integer.parseInt(args[2]);
			    end = (Integer.parseInt(args[1])+1)*Integer.parseInt(args[2]);
			    String key = null, val= null, op = null;
			    br = new BufferedReader(new FileReader(file1)); 
			    while ((line = br.readLine()) != null) {
			    	if(i >= start && i < end){
				    	key = line.split(",")[0].substring(0, 1);
				    	op = line.split(",")[4];
				    	val = line.split(",")[5];
				    	if(key.contains("."))
				    		key = key.substring(0, key.indexOf ( "." ));
				    	
				    	if(op.contains("."))
				    		op = op.substring(0, op.indexOf ( "." ));
				    	
				    	if(val.contains("."))
				    		val = val.substring(0, val.indexOf ( "." ));
				    	
				    	if(i==0)
				    		str = str + "<<" + i + "," + key + "," + op + "," + val +">>";
				    	else 
				    		str = str + ",<<" + i + "," + key + "," + op + "," + val +">>";
			    	 }
			    	i++;
			       // process the line.
			    }
			   /* FileOutputStream out = new FileOutputStream(pathFile+"training_data.arff");
			    out.write(str.getBytes());
			    out.close();*/
			//}
			 /*  catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}*/
			//str = args[0].replace("<", "<<");
			//str = str.replace(">", ">>");
			String[] sarr = str.split(">>,<<");
			//String[] sarr = str.replaceAll("\"", "").replaceAll("<", "<<").replaceAll(">", ">>").split(">>,<<");
			 String stStr = System.getProperty("line.separator")+"int size = "+sarr.length+";" + System.getProperty("line.separator");
			 //System.out.println("***before for loop setting stStr || str:"+str+" sarr size:"+sarr.length+" start:"+start+" end:"+end);
			 //+ "st[0].optype = w;"+System.getProperty("line.separator")+"st[0].var = x;"+System.getProperty("line.separator")+"st[0].val = 1;"+System.getProperty("line.separator")+"st[1].optype = w;"+System.getProperty("line.separator")+"st[1].var = x;"+System.getProperty("line.separator")+"st[1].val = 2;"+System.getProperty("line.separator")+"st[2].optype = r;"+System.getProperty("line.separator")+"st[2].var = x;"+System.getProperty("line.separator")+"st[2].val = 2;"+System.getProperty("line.separator")+"st[3].optype = r;"+System.getProperty("line.separator")+"st[3].var = x;"+System.getProperty("line.separator")+"st[3].val = 1;"+System.getProperty("line.separator");
				
			for(int ii=0; ii<sarr.length;ii++)
			 //for(int i=0; i< Integer.parseInt(args[1]);i++)
			{
				sarr[ii] = sarr[ii].replace("<", "");
				sarr[ii] = sarr[ii].replace(">", "");
				//System.out.println("st[0].optype = w;sarr[i]:"+sarr[i].split(",")[2]);
				stStr = stStr+"st["+ii+"].optype = "+sarr[ii].split(",")[1]+";"+ System.getProperty("line.separator") +"st["+ii+"].var = "+sarr[ii].split(",")[2]+";"+ System.getProperty("line.separator") +"st["+ii+"].val = "+sarr[ii].split(",")[3]+";"+ System.getProperty("line.separator");
			}
			List<String[]> retList = permute(Arrays.asList(sarr),0);
			//System.out.println("***1sarr 2:"+sarr.length +"3 retList.size():"+retList.size());
			//System.out.println("***** writing to file retarr:"+retList.size());
			String serStr = null;
			for(int l = 0; l < retList.size(); l++){
				serStr = Arrays.toString((String[])retList.get(l));
				if(serStr.contains("["))
					serStr = serStr.replace("[", "");
				if(serStr.contains("]"))
					serStr = serStr.replace("]", "");
				
				int count = 0;
				//System.out.println("***serStr::"+serStr);
				while(count < sarr.length){
				//while(count < Integer.parseInt(args[1])){
						stStr = stStr + "ser["+l+"].st["+count +"].optype = "+serStr.split(", ")[count].split(",")[1]+";"+ System.getProperty("line.separator") + "ser["+l+"].st["+count +"].var = "+serStr.split(", ")[count].split(",")[2]+";"+ System.getProperty("line.separator")+ "ser["+l+"].st["+count +"].val = "+serStr.split(", ")[count].split(",")[3]+";"+ System.getProperty("line.separator");
						count++;
				}
				
			}
			//System.out.println("***** writing al possible serializations to pml file Strtr:="+stStr);
			//String
			line = null;
			
		    
		    List<String> list = new ArrayList<String>();
		    
			//try{
				in = new BufferedReader(new FileReader(pathFile+"conspec"+args[0]+"Viol.pml"));
	            	while((str = in.readLine()) != null){
				        list.add(str);
				    }
	            	in.close();
	            	File file = new File(pathFile+"conspec"+args[0]+"Viol.pml");
	            	file.delete();
			/*} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			} catch (IOException e) {
				in = null;
				line = null;
			// TODO Auto-generated catch block
			e.printStackTrace();
			}  finally
			{
				// TODO Auto-generated catch block
				 	in = null;
				    line = null;
			}*/
			//try{
				    out = new Formatter(new FileWriter(pathFile+"conspec"+args[0]+"Viol.pml", true));
				    String[] stringArr = list.toArray(new String[0]);
				    //System.out.println("***stringArr.length::"+stringArr.length);
				    for (int iii = 0; iii < stringArr.length; iii++) {
			            line = stringArr[iii];
			            if (line.contains("init {")) {
			            	line = line + stStr;
			            }
			            out.format("\t %s \n", line);;
			            out.flush();
					}
		           
		            
		            out.close(); 
		            //System.exit(0);
				/*} catch (ConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			 finally
				{
					// TODO Auto-generated catch block
					 	in = null;
					    line = null;
					    out = null;
				}
	}

}
