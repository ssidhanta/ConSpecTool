package com.inesc.conspec.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ParseLog {
	private static String pathFile = "/Users/subhajitsidhanta/Downloads/Spin/";
	private static List<String[]> retList = new  ArrayList<String[]>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line = null;
		BufferedReader in = null;
		int i = 1;
		String str = "", strArr ="";
		FileOutputStream out = null;
	    //List<String> list = new ArrayList<String>();
	    boolean flagDel = true;
		try{
			in = new BufferedReader(new FileReader(pathFile+"logConSpec.log"));
            	while((str = in.readLine()) != null){
            		if(str.contains("Time diff is:")){
            			//if(i==0)
            				strArr = strArr + i + "," + str.split("Time diff is:")[1].split("seconds")[0].trim() + "\n";
    			    	//else 
    			    		//strArr = strArr + str.split("Time diff is:")[1].split("seconds")[0].trim()+ "\n";
            		    i++;
            		}	//strArr = strArr + ",";
            			//list.add(str);

            		//if(str.contains("init {"))
            		//	flagDel = true;
			    }
            	in.close();
            	out = new FileOutputStream(pathFile+"ExecLog.txt");
            	out.write(strArr.getBytes());
            	out.close();
            	
		} /*catch (ConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}*/ catch (IOException e) {
			in = null;
			line = null;
		// TODO Auto-generated catch block
		e.printStackTrace();
		}  finally
		{
			// TODO Auto-generated catch block
			 	in = null;
			    line = null;
			    out=null;
		}
	}

}
